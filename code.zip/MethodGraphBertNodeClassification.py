import torch
import torch.nn.functional as F
import torch.optim as optim

from transformers.models.bert.modeling_bert import BertPreTrainedModel
from code.MethodGraphBert import MethodGraphBert

from code.gcn import GCN

import time
import numpy as np
import pickle
from code.EvaluateAcc import EvaluateAcc
from sklearn import metrics
import os
# os.environ["CUDA_VISIBLE_DEVICES"] = "1"
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
BertLayerNorm = torch.nn.LayerNorm


device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def plot_Matrix(cm, classes, title=None, cmap=plt.cm.Greens):
    plt.rc('font', family='Times New Roman', size='3')  # 设置字体样式、大小

    # 按行进行归一化
    cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
    print("Normalized confusion matrix")
    str_cm = cm.astype(np.str).tolist()
    for row in str_cm:
        print('\t'.join(row))
    # 占比1%以下的单元格，设为0，防止在最后的颜色中体现出来
    # for i in range(cm.shape[0]):
    #     for j in range(cm.shape[1]):
    #         if int(cm[i, j] * 100 + 0.5) == 0:
    #             cm[i, j] = 0
    plt.rcParams.update({'font.size': 9})
    fig, ax = plt.subplots()
    im = ax.imshow(cm, interpolation='nearest', cmap=plt.cm.Greens)
    ax.figure.colorbar(im, ax=ax)  # 侧边的颜色条带

    ax.set(xticks=np.arange(cm.shape[1]),
            yticks=np.arange(cm.shape[0]),
            xticklabels=classes, yticklabels=classes,
            title=title,
            ylabel='Actual',
            xlabel='Predicted')

    # 通过绘制格网，模拟每个单元格的边框
    ax.set_xticks(np.arange(cm.shape[1] + 1) - .5, minor=True)
    ax.set_yticks(np.arange(cm.shape[0] + 1) - .5, minor=True)
    ax.grid(which="minor", color="gray", linestyle='-', linewidth=0.2)
    ax.tick_params(which="minor", bottom=False, left=False)

    # 将x轴上的lables旋转45度
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right",
            rotation_mode="anchor")

    # 标注百分比信息
    fmt = '.2f'
    thresh = 0.6
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, format(float(cm[i, j] * 100), fmt) + '%',
                    ha="center", va="center",
                    color="white" if cm[i, j] > thresh else "black")
            # if int(cm[i, j] * 100 + 0.5) > 0:
            #     ax.text(j, i, format(int(cm[i, j] * 100 + 0.5), fmt) + '%',
            #             ha="center", va="center",
            #             color="white" if cm[i, j] > thresh else "black")
    fig.tight_layout()
    plt.savefig('Data_Fusion.png', dpi=310)


class MethodGraphBertNodeClassification(BertPreTrainedModel):
    learning_record_dict = {}
    lr = 0.0001#0.0005
    weight_decay = 0.0005 #0.0005
    max_epoch = 2000#500,300
    spy_tag = True

    load_pretrained_path = ''
    save_pretrained_path = ''


    def __init__(self,config, dropout=0.5):#0.7
        # super(MethodGraphBertNodeClassification, self).__init__(config)
        super(MethodGraphBertNodeClassification, self).__init__(config)


        self.config = config




        # self.config.load_state_dict(torch.load('home/Graph-Bert-master/result/GraphBert/TFC2016_5_graph_recovery'))
        #
        self.bert = MethodGraphBert(config)








        #self.bert = torch.load('home/Graph-Bert-master/result/GraphBert/TFC2016_graph_recovery_model')

        # self.bert = torch.load('home/Graph-Bert-master/result/GraphBert/TFC2016_node_reconstruction_model')



        # MethodGraphBert = torch.load('home/Graph-Bert-master/result/GraphBert/TFC2016_5_graph_recovery')

        # self.res_h = torch.nn.Linear(config.x_size, config.hidden_size)
        # self.res_y = torch.nn.Linear(config.x_size, config.y_size)
        # self.cls_y = torch.nn.Linear(config.hidden_size, config.y_size)

        self.res_h = torch.nn.Sequential(
            torch.nn.Dropout(dropout),
            torch.nn.Linear(config.x_size, config.hidden_size, bias=True),
            torch.nn.BatchNorm1d(config.hidden_size)
        )

        self.res_y = torch.nn.Sequential(
            torch.nn.Dropout(dropout),
            torch.nn.Linear(config.x_size, config.y_size, bias=True),
            torch.nn.BatchNorm1d(config.y_size)
        )

        self.cls_y = torch.nn.Sequential(
            torch.nn.Dropout(dropout),
            torch.nn.BatchNorm1d(config.hidden_size),
            # torch.nn.Sigmoid(),
            torch.nn.Linear(config.hidden_size, config.y_size, bias=True),
            torch.nn.BatchNorm1d(config.y_size)
        )

        self.init_weights()









    def forward(self, raw_features, wl_role_ids, init_pos_ids, hop_dis_ids,idx=None):
    # def forward(self, raw_features, idx=None):
        residual_h, residual_y = self.residual_term()
        if idx is not None:
            if residual_h is None:
                outputs = self.bert(raw_features[idx], wl_role_ids[idx], init_pos_ids[idx], hop_dis_ids[idx], residual_h=None)
                # outputs = self.bert(raw_features[idx],residual_h=None)



            else:
                outputs = self.bert(raw_features[idx], wl_role_ids[idx], init_pos_ids[idx], hop_dis_ids[idx], residual_h=residual_h[idx])
                # outputs = self.bert(raw_features[idx],residual_h=residual_h[idx])

                residual_y = residual_y[idx]
        else:
            if residual_h is None:
                outputs = self.bert(raw_features, wl_role_ids, init_pos_ids, hop_dis_ids, residual_h=None)
                # outputs = self.bert(raw_features,residual_h=None)

            else:
                outputs = self.bert(raw_features, wl_role_ids, init_pos_ids, hop_dis_ids, residual_h=residual_h)
                # outputs = self.bert(raw_features, residual_h=residual_h)


        #import pudb;pu.db
        sequence_output = 0
        for i in range(self.config.k+1):
            sequence_output += outputs[0][:,i,:]
        sequence_output /= float(self.config.k+1)

        labels = self.cls_y(sequence_output)

        if residual_y is not None:
            labels += residual_y

        return F.log_softmax(labels, dim=1)

    def residual_term(self):
        if self.config.residual_type == 'none':
            return None, None
        elif self.config.residual_type == 'raw': 
            return self.res_h(self.data['X']), self.res_y(self.data['X'])
        elif self.config.residual_type == 'graph_raw':
            return torch.spmm(self.data['A'], self.res_h(self.data['X'])), torch.spmm(self.data['A'], self.res_y(self.data['X']))

    def train_model(self, max_epoch):


        # self.bert = torch.load('home/Graph-Bert-master/result/GraphBert/TFC2016_node_reconstruction_model')
        # self.bert.eval()

        # with open('home/Graph-Bert-master/result/PreTrained_GraphBert/TFC2016/node_classification_complete_model/pytorch_model.bin', 'rb') as f:
        #     obj = pickle.load(f)
        # weights = {key: weight_dict for key, weight_dict in pickle.loads(obj, encoding='latin1').items()}
        # import pudb;pu.db
        # self.load_state_dict(weights)



        # state_dict = torch.load('home/Graph-Bert-master/result/GraphBert/TFC2016_5_graph_recovery')
        # state_dict = state_dict['model']
        # for k, v in state_dict.items():
        #     print(k)



        t_begin = time.time()
        optimizer = optim.Adam(self.parameters(), lr=self.lr, weight_decay=self.weight_decay)
        accuracy = EvaluateAcc('', '')

        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        max_score = 0.0

        # model.load_state_dict(torch.load(PATH))
        # model.eval()

        # self.load_state_dict(torch.load('home/Graph-Bert-master/result/GraphBert/TFC2016_5_graph_recovery'))
        # self.eval()

        for epoch in range(max_epoch):
            t_epoch_begin = time.time()
            torch.cuda.empty_cache()
            # -------------------------

            self.train()
            optimizer.zero_grad()
            # import pudb;pu.db

            output = self.forward(self.data['raw_embeddings'], self.data['wl_embedding'], self.data['int_embeddings'], self.data['hop_embeddings'],  self.data['idx_train'])
            # output = self.forward(self.data['raw_embeddings'], self.data['idx_train'])

            loss_train = F.cross_entropy(output, self.data['y'][self.data['idx_train']]).to(device)
            accuracy.data = {'true_y': self.data['y'][self.data['idx_train']].to(device), 'pred_y': output.max(1)[1].to(device)}
            acc_train = accuracy.evaluate()

            loss_train.backward()
            optimizer.step()

            self.eval()
            output = self.forward(self.data['raw_embeddings'], self.data['wl_embedding'], self.data['int_embeddings'], self.data['hop_embeddings'],  self.data['idx_val'])
            # output = self.forward(self.data['raw_embeddings'], self.data['idx_val'])



            loss_val = F.cross_entropy(output, self.data['y'][self.data['idx_val']])
            accuracy.data = {'true_y': self.data['y'][self.data['idx_val']],
                             'pred_y': output.max(1)[1]}
            acc_val = accuracy.evaluate()

            #-------------------------
            #---- keep records for drawing convergence plots ----

            output = self.forward(self.data['raw_embeddings'], self.data['wl_embedding'], self.data['int_embeddings'], self.data['hop_embeddings'],  self.data['idx_test'])
            # output = self.forward(self.data['raw_embeddings'], self.data['idx_test'])

            loss_test = F.cross_entropy(output, self.data['y'][self.data['idx_test']])

            accuracy.data = {'true_y': self.data['y'][self.data['idx_test']],
                             'pred_y': output.max(1)[1]}
            acc_test = accuracy.evaluate()

            self.learning_record_dict[epoch] = {'loss_train': loss_train.item(), 'acc_train': acc_train.item(),
                                                'loss_val': loss_val.item(), 'acc_val': acc_val.item(),
                                                'loss_test': loss_test.item(), 'acc_test': acc_test.item(),
                                                'time': time.time() - t_epoch_begin}



            # -------------------------
            if epoch % 10 == 0:
                print('Epoch: {:04d}'.format(epoch + 1),
                      'loss_train: {:.4f}'.format(loss_train.item()),
                      'acc_train: {:.4f}'.format(acc_train.item()),
                      'loss_val: {:.4f}'.format(loss_val.item()),
                      'acc_val: {:.4f}'.format(acc_val.item()),
                      'loss_test: {:.4f}'.format(loss_test.item()),
                      'acc_test: {:.4f}'.format(acc_test.item()),
                      'time: {:.4f}s'.format(time.time() - t_epoch_begin))

        print("Optimization Finished!")
        print("Total time elapsed: {:.4f}s".format(time.time() - t_begin) + ', best testing performance {: 4f}'.format(np.max([self.learning_record_dict[epoch]['acc_test'] for epoch in self.learning_record_dict])) + ', minimun loss {: 4f}'.format(np.min([self.learning_record_dict[epoch]['loss_test'] for epoch in self.learning_record_dict])))
        
        true_y = self.data['y'][self.data['idx_test']]
        true_y = true_y.tolist()
        pred_y = output.max(1)[1]
        pred_y = pred_y.tolist()
        #import pudb;pu.db
        print("Test Precision, Recall and F1-Score...")
        print(metrics.classification_report(true_y, pred_y, digits=4))
        print("Macro average Test Precision, Recall and F1-Score...")
        print(metrics.precision_recall_fscore_support(true_y, pred_y, average='macro'))
        print("Micro average Test Precision, Recall and F1-Score...")
        print(metrics.precision_recall_fscore_support(true_y, pred_y, average='micro'))

        matrix = confusion_matrix(true_y, pred_y)
        # classes = ['BFSSH', 'DDOS', 'HTTPDOS', 'Infiltrating']
        # plot_Matrix(matrix, classes, title='CIC IDS2012(LSGLM)')

        # classes = ['MSSQL', 'NetBIOS', 'SYN', 'UDP', 'UDP-Lag']
        # plot_Matrix(matrix, classes, title='CIC DDoS2019(LSGLM)')

        # classes = ['Zeus', 'Tinba', 'Shifu', 'Nsis-ay', 'Miuref', 'Htbot', 'Cridex', 'Benign']
        # plot_Matrix(matrix, classes, title='USTC TFC2016(LSGLM)')

        classes = ['flood', 'BruteForce']
        plot_Matrix(matrix, classes, title='CIC IOT2022(LSGLM)')

        return time.time() - t_begin, np.max([self.learning_record_dict[epoch]['acc_test'] for epoch in self.learning_record_dict])

    def run(self):

        self.train_model(self.max_epoch)

        return self.learning_record_dict