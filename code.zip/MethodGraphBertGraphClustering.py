import torch

from transformers.models.bert.modeling_bert import BertPreTrainedModel
from code.MethodGraphBert import MethodGraphBert

import time

from sklearn.cluster import KMeans
from sklearn import metrics
import numpy as np
from scipy.optimize import linear_sum_assignment
import pandas as pd
#python /data/lyq/home/Graph-Bert-master/script_1_preprocess.py


BertLayerNorm = torch.nn.LayerNorm

# class MethodGraphBertGraphClustering(BertPreTrainedModel):
#     learning_record_dict = {}
#     use_raw_feature = True
#     cluster_number = 11
#     lr = 0.001
#     weight_decay = 5e-4
#     max_epoch = 500
#     load_pretrained_path = ''
#     save_pretrained_path = ''
#
#     def __init__(self, config):
#         super(MethodGraphBertGraphClustering, self).__init__(config)
#         self.config = config
#         self.bert = MethodGraphBert(config)
#         self.init_weights()
#
#
#     def acc(self,y_true, y_pred):
#         """
#         Calculate clustering accuracy. Require scikit-learn installed
#         # Arguments
#             y: true labels, numpy.array with shape `(n_samples,)`
#             y_pred: predicted labels, numpy.array with shape `(n_samples,)`
#         # Return
#             accuracy, in [0,1]
#         """
#         # import pudb;pu.db
#
#
#         # y_true = torch.tensor((y_true).cpu().numpy())
#         #
#         # y_pred = torch.tensor(np.array(torch.tensor(y_pred).cpu())).to(device)
#         # y_true = torch.tensor(np.array(y_true).astype(np.int64)).cpu().to(device)
#
#         y_true = torch.tensor(y_true).cpu()
#         y_true = y_true.numpy()
#
#         y_pred = torch.tensor(y_pred).cpu()
#         y_pred = np.array(y_pred)
#         y_true = np.array(y_true).astype(np.int64)
#
#
#         assert y_pred.size == y_true.size
#         D = max(y_pred.max(), y_true.max()) + 1
#         w = np.zeros((D, D), dtype=np.int64)
#         for i in range(y_pred.size):
#             w[y_pred[i], y_true[i]] += 1
#         ind = linear_sum_assignment(w.max() - w)
#         ind = np.array(ind).T
#         # return sum([w[i, j] for i, j in ind]) * 1.0 / y_pred.size
#
#         return sum([w[i, j] for i, j in zip(ind[0], ind[1])]) * 1.0 / y_pred.size
#
#
#     def forward(self, raw_features, wl_role_ids, init_pos_ids, hop_dis_ids):
#         device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
#         outputs = self.bert(raw_features, wl_role_ids, init_pos_ids, hop_dis_ids)
#
#         sequence_output = 0
#         for i in range(self.config.k+1):
#             sequence_output += outputs[0][:,i,:]
#         sequence_output /= float(self.config.k+1)
#
#         kmeans = KMeans(n_clusters=self.cluster_number, max_iter=self.max_epoch)
#
#
#         self.data['X'] = torch.tensor(self.data['X']).cpu()
#
#         if self.use_raw_feature:
#             # clustering_result = kmeans.fit_predict(self.data['X'])
#             clustering_result = torch.tensor(kmeans.fit_predict(self.data['X'])).cpu().to(device)
#             data1 = self.data['X'].to(device)
#         else:
#             clustering_result = kmeans.fit_predict(sequence_output.tolist())
#             data1 = sequence_output.tolist()
#
#         # accuracy.data = {'true_y': self.data['y'],
#         #                  'pred_y': clustering_result}
#         # acc_val = accuracy.evaluate()
#         # print('true_y'.format(self.data['y']),'pred_y'.format(clustering_result))
#
#         label_clf = kmeans.labels_
#
#         true_y = self.data['y']
#         pred_y = clustering_result
#         print(self.acc(true_y, pred_y))
#
#         center = kmeans.cluster_centers_
#
#         import pudb;pu.db
#         df_center = pd.DataFrame(center, columns=['x', 'y'])
#
#         df = pd.DataFrame(data1, index=label_clf, columns=['x', 'y'])
#         df1 = df[df.index == 0]
#         df2 = df[df.index == 1]
#         df3 = df[df.index == 2]
#         df4 = df[df.index == 3]
#         df5 = df[df.index == 4]
#
#         plt.figure(figsize=(10, 8), dpi=80)
#         axes = plt.subplot()
#         type1 = axes.scatter(df1.loc[:, ['x']], df1.loc[:, ['y']], s=10, c='red', marker='d')
#         type2 = axes.scatter(df2.loc[:, ['x']], df2.loc[:, ['y']], s=10, c='green', marker='*')
#         type3 = axes.scatter(df3.loc[:, ['x']], df3.loc[:, ['y']], s=10, c='black', marker='p')
#         type4 = axes.scatter(df4.loc[:, ['x']], df4.loc[:, ['y']], s=10, c='blue', marker='*')
#         type5 = axes.scatter(df5.loc[:, ['x']], df5.loc[:, ['y']], s=10, c='yellow', marker='p')
#         type_center = axes.scatter(df_center.loc[:, 'x'], df_center.loc[:, 'y'], s=40, c='blue')
#         plt.xlabel('x', fontsize=16)
#         plt.ylabel('y', fontsize=16)
#         axes.legend((type1, type2, type3, type4, type5,type_center), ('0', '1', '2', '3', '4', 'center'), loc=1)
#         plt.savefig('home/Graph-Bert-master/ids2012-clustering.png')
#         # plt.show()
#
#         return {'pred_y': clustering_result, 'true_y': self.data['y']}
#
#     def train_model(self, max_epoch):
#         t_begin = time.time()
#         # device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
#         # self.data['raw_embeddings'] = torch.tensor(self.data['raw_embeddings']).to(device)
#         # self.data['wl_embedding'] = torch.tensor(self.data['wl_embedding']).to(device)
#         # self.data['int_embeddings'] = torch.tensor(self.data['int_embeddings']).to(device)
#         # self.data['hop_embeddings'] = torch.tensor(self.data['hop_embeddings']).to(device)
#
#         clustering = self.forward(self.data['raw_embeddings'], self.data['wl_embedding'], self.data['int_embeddings'],self.data['hop_embeddings'])
#
#         # loss = F.cross_entropy(clustering, self.data['y'][self.data['idx_train']])
#         # accuracy.data = {'true_y': self.data['y'][self.data['idx_train']], 'pred_y': clustering.max(1)[1]}
#         # acc_train = accuracy.evaluate()
#
#         self.learning_record_dict = clustering
#
#     def run(self):
#
#         self.train_model(self.max_epoch)
#
#         return self.learning_record_dict














class MethodGraphBertGraphClustering(BertPreTrainedModel):
    learning_record_dict = {}
    use_raw_feature = True
    cluster_number = 11
    lr = 0.001
    weight_decay = 5e-4
    max_epoch = 500
    load_pretrained_path = ''
    save_pretrained_path = ''

    def __init__(self, config):
        super(MethodGraphBertGraphClustering, self).__init__(config)
        self.config = config
        self.bert = MethodGraphBert(config)
        self.init_weights()

    def acc(self, y_true, y_pred):
        """
        Calculate clustering accuracy. Require scikit-learn installed
        # Arguments
            y: true labels, numpy.array with shape `(n_samples,)`
            y_pred: predicted labels, numpy.array with shape `(n_samples,)`
        # Return
            accuracy, in [0,1]
        """
        # import pudb;pu.db

        # y_true = torch.tensor((y_true).cpu().numpy())
        #
        # y_pred = torch.tensor(np.array(torch.tensor(y_pred).cpu())).to(device)
        # y_true = torch.tensor(np.array(y_true).astype(np.int64)).cpu().to(device)

        y_true = y_true.numpy()

        y_pred = np.array(y_pred)
        y_true = np.array(y_true).astype(np.int64)

        assert y_pred.size == y_true.size
        D = max(y_pred.max(), y_true.max()) + 1
        w = np.zeros((D, D), dtype=np.int64)
        for i in range(y_pred.size):
            w[y_pred[i], y_true[i]] += 1
        ind = linear_sum_assignment(w.max() - w)
        ind = np.array(ind).T
        # return sum([w[i, j] for i, j in ind]) * 1.0 / y_pred.size

        return sum([w[i, j] for i, j in zip(ind[0], ind[1])]) * 1.0 / y_pred.size

    def forward(self, raw_features, wl_role_ids, init_pos_ids, hop_dis_ids):

        outputs = self.bert(raw_features, wl_role_ids, init_pos_ids, hop_dis_ids)

        sequence_output = 0
        for i in range(self.config.k + 1):
            sequence_output += outputs[0][:, i, :]
        sequence_output /= float(self.config.k + 1)

        kmeans = KMeans(n_clusters=self.cluster_number, max_iter=self.max_epoch)

        self.data['X'] = torch.tensor(self.data['X'])

        if self.use_raw_feature:
            # clustering_result = kmeans.fit_predict(self.data['X'])
            clustering_result = kmeans.fit_predict(self.data['X'])

        else:
            clustering_result = kmeans.fit_predict(sequence_output.tolist())
            data1 = sequence_output.tolist()

        # accuracy.data = {'true_y': self.data['y'],
        #                  'pred_y': clustering_result}
        # acc_val = accuracy.evaluate()
        # print('true_y'.format(self.data['y']),'pred_y'.format(clustering_result))

        label_clf = kmeans.labels_

        true_y = self.data['y']
        pred_y = clustering_result
        print(self.acc(true_y, pred_y))

        center = kmeans.cluster_centers_


        df_center = pd.DataFrame(center, columns=['x', 'y'])

        df = pd.DataFrame(data1, index=label_clf, columns=['x', 'y'])
        df1 = df[df.index == 0]
        df2 = df[df.index == 1]
        df3 = df[df.index == 2]
        df4 = df[df.index == 3]
        df5 = df[df.index == 4]

        plt.figure(figsize=(10, 8), dpi=80)
        axes = plt.subplot()
        type1 = axes.scatter(df1.loc[:, ['x']], df1.loc[:, ['y']], s=10, c='red', marker='d')
        type2 = axes.scatter(df2.loc[:, ['x']], df2.loc[:, ['y']], s=10, c='green', marker='*')
        type3 = axes.scatter(df3.loc[:, ['x']], df3.loc[:, ['y']], s=10, c='black', marker='p')
        type4 = axes.scatter(df4.loc[:, ['x']], df4.loc[:, ['y']], s=10, c='blue', marker='*')
        type5 = axes.scatter(df5.loc[:, ['x']], df5.loc[:, ['y']], s=10, c='yellow', marker='p')
        type_center = axes.scatter(df_center.loc[:, 'x'], df_center.loc[:, 'y'], s=40, c='blue')
        plt.xlabel('x', fontsize=16)
        plt.ylabel('y', fontsize=16)
        axes.legend((type1, type2, type3, type4, type5, type_center), ('0', '1', '2', '3', '4', 'center'), loc=1)
        plt.savefig('home/Graph-Bert-master/ids2012-clustering.png')
        # plt.show()

        return {'pred_y': clustering_result, 'true_y': self.data['y']}

    def train_model(self, max_epoch):
        t_begin = time.time()
        # device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        # self.data['raw_embeddings'] = torch.tensor(self.data['raw_embeddings']).to(device)
        # self.data['wl_embedding'] = torch.tensor(self.data['wl_embedding']).to(device)
        # self.data['int_embeddings'] = torch.tensor(self.data['int_embeddings']).to(device)
        # self.data['hop_embeddings'] = torch.tensor(self.data['hop_embeddings']).to(device)

        clustering = self.forward(self.data['raw_embeddings'], self.data['wl_embedding'], self.data['int_embeddings'],
                                  self.data['hop_embeddings'])

        # loss = F.cross_entropy(clustering, self.data['y'][self.data['idx_train']])
        # accuracy.data = {'true_y': self.data['y'][self.data['idx_train']], 'pred_y': clustering.max(1)[1]}
        # acc_train = accuracy.evaluate()

        self.learning_record_dict = clustering

    def run(self):

        self.train_model(self.max_epoch)

        return self.learning_record_dict



