'''
Concrete MethodModule class for a specific learning MethodModule
'''

# Copyright (c) 2017 Jiawei Zhang <jwzhanggy@gmail.com>
# License: TBD

from code.base_class.method import method


class MethodGraphBatching(method):
    data = None
    k = 5

    def run(self):
        S = self.data['S']
        index_id_dict = self.data['index_id_map']#{0: 2586, 1: 1499, 2: 2819,.....}

        user_top_k_neighbor_intimacy_dict = {}
        for node_index in index_id_dict:
            #import pudb;pu.db
            node_id = index_id_dict[node_index]#2586
            s = S[node_index]#array([-1.00000000e+03,  2.85469496e-04, 3.49268715e-04, ..., 3.04176118e-04,  2.69811529e-04, 3.17338320e-04]),len:3000
            s[node_index] = -1000.0

            #argsort函数:返回数组值从小到大的索引值
            top_k_neighbor_index = s.argsort()[-self.k:][::-1] #array([2630])
            user_top_k_neighbor_intimacy_dict[node_id] = []
            for neighbor_index in top_k_neighbor_index:
                neighbor_id = index_id_dict[neighbor_index]
                user_top_k_neighbor_intimacy_dict[node_id].append((neighbor_id, s[neighbor_index]))
            #import pudb;pu.db
        return user_top_k_neighbor_intimacy_dict #{2586: [(2038, 0.0003499304812937863)]}




