#!/usr/bin/env python
import torch
import torch.nn as nn


class GraphConvolution(nn.Module):
    def __init__( self, input_dim, \
                        output_dim, \
                        support, \
                        act_func = None, \
                        featureless = False, \
                        dropout_rate = 0., \
                        bias=False):
        super(GraphConvolution, self).__init__()
        self.support = support
        self.featureless = featureless

        for i in range(len(self.support)):
            setattr(self, 'W{}'.format(i), nn.Parameter(torch.randn(input_dim, output_dim)))

        if bias:
            self.b = nn.Parameter(torch.zeros(1, output_dim))

        self.act_func = act_func
        self.dropout = nn.Dropout(dropout_rate)

        
    def forward(self, x):
        x = self.dropout(x)

        for i in range(len(self.support)):
            if self.featureless:
                pre_sup = getattr(self, 'W{}'.format(i))
            else:
                pre_sup = x.mm(getattr(self, 'W{}'.format(i)))
            
            if i == 0:
                out = self.support[i].mm(pre_sup)
            else:
                out += self.support[i].mm(pre_sup)

        if self.act_func is not None:
            out = self.act_func(out)
        #out = self.dropout(out)
        self.embedding = out
        return out

class Dense(nn.Module):
    def __init__(self, num_classes):
        super(Dense, self).__init__()
        self.fc = nn.Linear(128, num_classes)
        self.dropout = nn.Dropout(0.5)

    def forward(self, x):
        out = self.fc(x)
        out = self.dropout(out)
        return out
    
class GCN(nn.Module):
    def __init__( self, input_dim, \
                        support,\
                        dropout_rate=0.5, \
                        num_classes=10):
        super(GCN, self).__init__()
        
        # GraphConvolution
        self.layer1 = GraphConvolution(input_dim, 32, support, act_func=nn.ReLU(), featureless=True, dropout_rate=dropout_rate)
        self.layer2 = GraphConvolution(32, num_classes, support, dropout_rate=dropout_rate)
#         self.layer2 = GraphConvolution(512, 128, support, act_func=nn.ReLU(), dropout_rate=dropout_rate)
#         self.layer3 = GraphConvolution(64, num_classes, support, dropout_rate=dropout_rate)
        #self.fc = nn.Linear(100, 10)
        
    
    def forward(self, x):
        out = self.layer1(x)
        out = self.layer2(out)
#         out = self.layer3(out)
        #out = self.fc(out)
        return out
